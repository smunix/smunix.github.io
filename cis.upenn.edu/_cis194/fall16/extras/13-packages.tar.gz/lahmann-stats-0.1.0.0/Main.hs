import qualified Data.ByteString.Lazy as LBS
import Text.Blaze.Html.Renderer.Utf8

import Data.Lahmann.Parser
import Data.Lahmann.Stats
import Data.Lahmann.Stats.Html

import Options.Applicative

data Conf = Conf
    { dataDir :: String
    , outputFileName :: String
    }

conf :: Parser Conf
conf = Conf
  <$> strOption
      ( long "dataDir"
     <> short 'd'
     <> metavar "DIR"
     <> help "Directory of downloaded Lahmann stats"
     <> value "."
     <> showDefault
     )
  <*> strOption
      ( long "output"
     <> short 'o'
     <> metavar "FILE"
     <> help "Output filename"
     <> value "stats.html"
     <> showDefault
     )

run :: Conf -> IO ()
run conf = do
    battingSums <- readBattingStats (dataDir conf)
    playerMap <- readPlayerStats (dataDir conf)

    let stats = genStats battingSums playerMap
    let htmlFile = mkHtmlStats stats
    LBS.writeFile (outputFileName conf) (renderHtml htmlFile)


main :: IO ()
main = execParser opts >>= run
  where
    opts = info (helper <*> conf)
      ( fullDesc
     <> progDesc "Creates statistics from baseball database"
     <> header "lehmann-stats - baseball stats")
