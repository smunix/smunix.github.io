module Data.Lahmann.Stats (genStats) where

import Data.List
import qualified Data.Map as M
import qualified Data.Vector as V
import Statistics.Correlation
import Data.Ord

import Data.Lahmann.Types

homerunProb :: Batting -> Double
homerunProb b | atBats b > 0 = fromIntegral (homeruns b) / fromIntegral (atBats b)
              | otherwise    = 0


ppName :: Player -> String
ppName p = nameGiven p ++ " " ++ nameLast p


genStats :: M.Map PlayerID Batting -> M.Map PlayerID Player -> (Int, Double, [(String, Double)])
genStats battingSums playerMap = (length stats, cor, top10')
  where
    stats = M.intersectionWith (,) playerMap battingSums

    cor = pearson $ V.fromList
                [ (fromIntegral (birthYear p), homerunProb b)
                | (p,b) <- M.elems stats ]

    top10 = take 10 $ sortOn (Down . homerunProb . snd) $ M.elems stats
    top10' = [ (ppName p, homerunProb b) | (p,b) <- top10 ]
