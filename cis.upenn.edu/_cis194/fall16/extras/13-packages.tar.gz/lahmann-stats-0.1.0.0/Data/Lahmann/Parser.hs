{-# LANGUAGE OverloadedStrings, DeriveGeneric #-}
module Data.Lahmann.Parser (readPlayerStats, readBattingStats) where

import Data.Csv
import qualified Data.Vector as V
import qualified Data.ByteString.Lazy as LBS
import qualified Data.Map.Strict as M
import Control.Applicative
import System.IO
import System.Exit
import System.FilePath

import Data.Lahmann.Types

instance FromNamedRecord Batting where
    parseNamedRecord m =
        Batting <$> m .: "playerID"
                <*> (m .: "AB" <|> pure 0)
                <*> (m .: "HR" <|> pure 0)

instance FromNamedRecord Player where
    parseNamedRecord m =
        Player  <$> m .: "playerID"
                <*> m .: "nameGiven"
                <*> m .: "nameLast"
                <*> (m .: "birthYear" <|> pure 1900)

addBattingSums :: Batting -> Batting -> Batting
addBattingSums b1 b2 = Batting
    { battingID = battingID b1
    , atBats = atBats b1 + atBats b2
    , homeruns = homeruns b1 + homeruns b2
    }

type BattingSums = M.Map PlayerID Batting

initBattingSum = M.empty

tallyBattingSum :: BattingSums -> Batting -> BattingSums
tallyBattingSum m b = M.insertWith addBattingSums (battingID b) b m

readBattingStats :: FilePath -> IO (M.Map PlayerID Batting)
readBattingStats dirname = do
    rawBatting <- LBS.readFile $ dirname </> "Batting.csv"
    batting <- case decodeByName rawBatting of
        Left error -> do
            hPutStrLn stderr error
            exitFailure
        Right (_header, players) -> return players
    return $ V.foldl tallyBattingSum initBattingSum batting

-- | Reads the player data from a downloaded copy of Lahmann's baseball
-- statistics <http://seanlahman.com/baseball-archive/statistics/>.
--
-- The first parameter indicates the directory name where the files can be found.
readPlayerStats :: FilePath -> IO (M.Map PlayerID Player)
readPlayerStats dirname = do
    rawPlayers <- LBS.readFile $ dirname </> "Master.csv"
    players <- case decodeByName rawPlayers of
        Left error -> do
            hPutStrLn stderr error
            exitFailure
        Right (_header, players) -> return players
    return $ M.fromList [ (playerID p, p) | p <- V.toList players ]

