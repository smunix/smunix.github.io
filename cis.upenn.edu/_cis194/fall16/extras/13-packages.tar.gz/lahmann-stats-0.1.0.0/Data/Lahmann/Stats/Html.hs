{-# LANGUAGE OverloadedStrings #-}

module Data.Lahmann.Stats.Html where

import Text.Blaze.Html5 as H hiding (main)
import Data.Foldable

mkHtmlStats :: (Int, Double, [(String, Double)]) -> Html
mkHtmlStats (n, corr, top10) = docTypeHtml $ do
     H.head $ do
        H.title "My baseball stats"
     body $ do
        h1 "My baseball stats"
        h2 "General statistics"
        p $ do
            "We have stats for "
            toHtml n
            " players."
        p $ do
            "Homerun probability correlates with birth year by "
            toHtml corr
            "."
        h2 "Top 10"
        table $ do
            tr $ do
                th "Player"
                th "Prob"
            for_ top10 $ \(p,b) ->
                tr $ do
                    td (toHtml p)
                    td (toHtml b)

