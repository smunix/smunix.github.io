{-# LANGUAGE DeriveGeneric #-}
module Data.Lahmann.Types where

type PlayerID = String

data Batting = Batting
    { battingID :: PlayerID
    , atBats    :: !Int
    , homeruns  :: !Int
    } deriving Show

data Player = Player
    { playerID  :: PlayerID
    , nameGiven :: String
    , nameLast  :: String
    , birthYear :: Integer
    } deriving Show

